#include <iostream>
#include<iomanip>
#include "Tpracownik.h"
#include "Tdzialania.h"
#include "Tstudent.h"

using namespace std;
int main()
{
    cout<<"PROGRAM: PRACOWNIKI"<<endl;
    Tpracownik pracownik;
    pracownik.Vczytaj();
    pracownik.Vyswietl();

    cout<<endl<<"PROGRAM: DZIALANIA"<<endl;
    Tdzialania dzialania;
    dzialania.podajDane();
    cout<<"Iloczyn "<<dzialania.iloczyn()<<endl;
    cout<<"Ilraz "<<dzialania.iloraz()<<endl;
    cout<<"Potegowanie "<<dzialania.potegowanie()<<endl;

    cout<<endl<<"PROGRAM: STUDENCI"<<endl;
    Tstudent student;
    student.Vczytanie_danych();
    cout<<"Srednia ocena = "<<setprecision(3)<<student.Srednia()<<endl;

    system("PAUSE");
    return EXIT_SUCCESS;

}

