#ifndef TDZIALANIA_H
#define TDZIALANIA_H

using namespace std;
class Tdzialania
{
    private:
        int a,b;
    public:
        void podajDane();
        int iloczyn();
        float iloraz();
        int potegowanie();
};

#endif // TDZIALANIA_H
