#ifndef TPRACOWNIK_H
#define TPRACOWNIK_H


using namespace std;
struct Tdata{
    int dzien;
    int miesonc;
    int rok;
};
//1. Zadeklaruj klasy o odpowiednich polach i metodach

class Tpracownik{
private:
    char imie[10];
    char nazwisko[20];
    float stawkaG;
    int liczbaG;
    Tdata dataZ;
public:
    void Vczytaj();
    float Placa();
    void Vyswietl();
};
#endif // TPRACOWNIK_H
