#ifndef TSTUDENT_H
#define TSTUDENT_H

using namespace std;

class Tstudent
{
    private:
      char imie_studenta[10];
      char nazwizko[20];
      float ocena[3];

    public:
        void Vczytanie_danych();
        float Srednia();

};

#endif // TSTUDENT_H
