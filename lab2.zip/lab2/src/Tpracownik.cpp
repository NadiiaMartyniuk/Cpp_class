#include "Tpracownik.h"
#include<iostream>
//2. Zdefiniuj metody zadeklarowane w klasie
void Tpracownik::Vczytaj(){
    int temp_g;
    float temp_s;
    cout<<"Podaj imie ";
    cin>>imie;
    cout<<"Podaj nazwisko ";
    cin>>nazwisko;
    cout<<"Jaka stawka ";
    cin>>temp_s;
    if (temp_s<0){
        cout<<"Wprowadzono zly dane "<<endl<<"Stawka zostala zamieniona na 0"<<endl;
        stawkaG=0;
    }
    else stawkaG=temp_s ;
    cout<<"Liczba godzin ";
    cin>>temp_g;
    if (temp_g<0){
        cout<<"Wprowadzono zly dane "<<endl<<"Liczba godzin zostala zamieniona na 0"<<endl;
        liczbaG=0;
    }
    else liczbaG=temp_g ;
    cout<<"Dzien zatrudnienia ";
    cin>>dataZ.dzien;
    cout<<"Miesionc zatrudnienia ";
    cin>>dataZ.miesonc;
    cout<<"Rok zatrudnienia ";
    cin>>dataZ.rok;
}
float Tpracownik::Placa(){
    return liczbaG*stawkaG;
}
void Tpracownik::Vyswietl(){
    //Pracownik Jan Kowalski zatrudniony wtedy i wtedy otrzyma ...
    cout<<endl<<"Pracownik "<<imie<<" "<<nazwisko<<" zatrudniony "<<dataZ.dzien<<"."<<dataZ.miesonc<<"."<<dataZ.rok<<" otrzymuje "<<Placa()<<endl;
}
