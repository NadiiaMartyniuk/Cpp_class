#include "Tdzialania.h"
#include<iostream>
#include<math.h>

void Tdzialania::podajDane()
{cout<<"Podaj dwie liczby calkowite "; cin>>a>>b;
 }
int Tdzialania::iloczyn()
{return a*b;
 }
float Tdzialania::iloraz()
{
    if (b){
            return (a*1.0)/b;
    }
    else {
            cout<<"Dzielenie przez zero"<<endl;
            return 0;}

 }
 int Tdzialania::potegowanie()
{return pow(a,b);
 }



