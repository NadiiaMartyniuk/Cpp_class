#include "Tstudent.h"
#include <iostream>
using namespace std;
void Tstudent::Vczytanie_danych(){
    cout<<"Imie studenta: ";
    cin>>imie_studenta;
    cout<<"Nazwizko studenta: ";
    cin>>nazwizko;
    float temp;
    for (int i=0; i<3; i++){
        cout<<"Ocena z "<<i+1<<" egzaminu ";
        cin>>temp;
        if ((temp>5)||(temp<2)){
            cout<<"Wprowadzona ocena nie poprawna"<<endl;
            cout<<"Wprowadzona ocena zostala zamieniona na ocenu 2"<<endl;
            ocena[i]=2;
        }
        else ocena[i]=temp;
    }
}

float Tstudent::Srednia(){
    float sum;
    for (int i=0; i<3; i++){
        sum += ocena[i];
    }
    return sum/3;
}
